import 'dart:io';

List<String> inputBuah() {
  int jumlah;
  do {
    print('Masukan jumlah nama buah yang ingin anda masukkan (minimal 5): ');
    String? input = stdin.readLineSync();
    jumlah = int.tryParse(input ?? '') ?? 0;
    if (jumlah < 5) {
      print('Minimal nama buah adalah 5');
    }
  } while (jumlah < 5);

  List<String> listBuah = [];
  for (int i = 0; i < jumlah; i++) {
    String? namaBuah;
    do {
      print('Masukkan nama buah ke-${i + 1}: ');
      namaBuah = stdin.readLineSync()?.trim();
      if (namaBuah == null || namaBuah.isEmpty) {
        print('Masukkan nama buah yang valid!');
      }
    } while (namaBuah == null || namaBuah.isEmpty);
    listBuah.add(namaBuah);
  }
  return listBuah;
}

void main() {
  List<String> buahFavorit = inputBuah();
  print('Buah favorit Anda: ${buahFavorit.join(', ')}');
}
